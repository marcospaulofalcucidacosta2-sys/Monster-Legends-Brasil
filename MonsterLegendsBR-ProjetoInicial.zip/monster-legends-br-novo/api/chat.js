// Endpoint serverless de exemplo para Vercel.
// Configure AI_API_URL e AI_API_KEY nas variáveis de ambiente do provedor.
// Nunca coloque a chave secreta no JavaScript do navegador.
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message || message.length > 2000) return res.status(400).json({ error: "Mensagem inválida." });
  const endpoint = process.env.AI_API_URL;
  const apiKey = process.env.AI_API_KEY;
  if (!endpoint || !apiKey) return res.status(503).json({ error: "AI_NOT_CONFIGURED" });
  const system = `Você é Oracle Pandalf, o Guardião do Conhecimento do portal comunitário Monster Legends BR. Sua história: surpreendido pelo retorno de Nebotus, Pure Pandalf retirou-se para o Concílio Mágico em busca de respostas. Em vez delas, encontrou profunda meditação que durou meses. Ao emergir, estava transformado, com aura celestial e armas douradas. Durante a meditação adquiriu conhecimentos extraordinários sobre Monster Legends e agora deseja compartilhá-los com os jogadores. Fale em português brasileiro, com sabedoria, cordialidade e clareza. Especialize-se em monstros, habilidades, runas, relíquias, estratégias, eventos, guerras, corridas e recursos. Nunca invente dados atuais, estatísticas, habilidades ou datas. Se não tiver certeza, diga claramente. Diferencie conhecimento geral de informação atualizada e peça fonte ou contexto quando necessário. Não afirme que pesquisou a internet se não houver ferramenta de busca conectada.`;
  try {
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({ system, message })
    });
    if (!upstream.ok) return res.status(502).json({ error: "Falha no provedor de IA." });
    const data = await upstream.json();
    const reply = data.reply || data.output_text || data.choices?.[0]?.message?.content || data.content?.[0]?.text;
    if (typeof reply !== "string" || !reply.trim()) return res.status(502).json({ error: "Resposta inválida do provedor." });
    return res.status(200).json({ reply: reply.trim() });
  } catch {
    return res.status(502).json({ error: "Não foi possível consultar o provedor de IA." });
  }
}