# Monster Legends BR — novo projeto

Portal comunitário responsivo com identidade visual inspirada em fantasia/magia e personagem de IA Oracle Pandalf.

## O que já funciona neste MVP
- Layout responsivo para celular e computador.
- Navegação por seções.
- Biblioteca com filtros e busca.
- Guias iniciais editáveis em `main.js`.
- Ferramentas locais: estimativa de tarefas, sugestão básica de runas e simulador hipotético de gemas.
- Janela de conversa com Oracle Pandalf.
- Endpoint de IA preparado em `api/chat.js`, com chave protegida no servidor.

## Importante sobre a IA
A interface e o endpoint estão preparados, mas a IA **não está ativa até configurar um provedor compatível**. É necessário escolher um provedor com plano gratuito vigente, criar a chave e configurar `AI_API_URL` e `AI_API_KEY` como variáveis de ambiente no serviço de hospedagem. Não coloque a chave no `main.js` nem em arquivos públicos. O endpoint é um adaptador genérico; o formato do corpo pode precisar de ajuste para o provedor escolhido.

Este MVP não faz pesquisa na internet em tempo real. Para isso será necessário conectar uma API de busca e instruir Pandalf a citar links e datas. Não prometa respostas ilimitadas ou gratuitas: provedores podem impor cotas e alterar seus planos.

## Executar localmente
Requer Node.js instalado.

```bash
npm install
npm run dev
```

Abra o endereço local mostrado pelo Vite.

## Publicar
Pode ser publicado em hospedagem estática gratuita para a parte visual. Para executar `/api/chat.js`, use uma hospedagem com funções serverless compatíveis (por exemplo, Vercel) e configure as variáveis de ambiente. Um host estático puro não executará o endpoint.

## Personalizar a arte do Oracle Pandalf
A imagem enviada pelo usuário serve como referência visual. O projeto inclui uma representação tipográfica temporária para não fingir que é a arte oficial. Se você tiver autorização para usar a imagem do jogo, salve-a como `public/images/oracle-pandalf.png` e atualize o bloco `.pandalf-placeholder` em `index.html` para exibir a imagem.

## Próximas etapas para produção
1. Configurar banco de dados e autenticação.
2. Criar painel administrativo e permissões de líder por equipe.
3. Persistir equipes, candidaturas, fóruns e conteúdo da biblioteca.
4. Integrar IA com base de conhecimento (RAG) e pesquisa web com fontes.
5. Adicionar testes automatizados, validação e monitoramento.
6. Revisar acessibilidade, segurança, privacidade e moderação antes de abrir cadastro público.

Projeto comunitário independente, sem vínculo oficial com Socialpoint.
