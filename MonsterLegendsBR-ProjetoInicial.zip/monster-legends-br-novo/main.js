const guides = [
 {icon:"♜",category:"Monstros",title:"Como avaliar um monstro",desc:"Entenda funções, atributos, habilidades e sinergias antes de investir recursos.",body:"Analise a função do monstro na equipe, seus atributos, habilidades, imunidades, efeitos de controle e sinergia com aliados. Consulte também a data da informação: atualizações podem alterar o equilíbrio do jogo."},
 {icon:"◈",category:"Runas",title:"Guia básico de runas",desc:"Conheça Força, Vida, Velocidade e combinações para diferentes funções.",body:"Runas de Força aumentam dano; Vida amplia resistência; Velocidade pode ajudar a controlar a ordem dos turnos. A combinação ideal depende da função, dos aliados e do modo de jogo. Não existe uma configuração universal."},
 {icon:"✧",category:"Estratégias",title:"Caverna do Tesouro",desc:"Dicas para planejar recursos e compreender os riscos de cada escolha.",body:"Defina um limite de gemas antes de entrar. Trate qualquer gasto como risco: não há garantia de encontrar uma recompensa específica. Evite gastar recursos que você precisa para eventos ou melhorias prioritárias."},
 {icon:"⚔",category:"Estratégias",title:"Preparação para guerras",desc:"Organize ataques, observe os adversários e combine funções na equipe.",body:"Antes da guerra, confira os adversários, as regras da equipe e o horário. Distribua responsabilidades, use seus ataques dentro do prazo e comunique dificuldades aos líderes."},
 {icon:"🏁",category:"Eventos",title:"Corridas e maratonas",desc:"Planeje tarefas, pontos e participação sem desperdiçar recursos.",body:"Leia os objetivos da corrida, combine tarefas com os membros e acompanhe o progresso. Pontuações e custos podem mudar por evento; confirme os valores na tela atual do jogo."},
 {icon:"✦",category:"Monstros",title:"Montando uma equipe equilibrada",desc:"Combine dano, suporte, controle e sobrevivência de acordo com o modo.",body:"Uma equipe equilibrada considera iniciativa, dano, suporte, controle e proteção. Teste combinações e adapte a estratégia ao adversário e ao modo de jogo."}
];
const teams = [
 {name:"Equipes em destaque",symbol:"♜",desc:"Espaço demonstrativo para equipes parceiras. Os perfis reais serão cadastrados pelos líderes.",meta:"Cadastro de equipes em preparação"},
 {name:"Recrutamento aberto",symbol:"⚑",desc:"Jogadores poderão encontrar equipes por requisitos, atividade e dias de guerra.",meta:"Filtros e candidaturas em desenvolvimento"},
 {name:"Sua equipe aqui",symbol:"✧",desc:"Líderes terão uma área própria para atualizar regras, membros e contatos.",meta:"Área do líder planejada"}
];
const guideGrid=document.querySelector("#guideGrid"), search=document.querySelector("#guideSearch");
let activeFilter="Todos";
function renderGuides(){const term=search.value.trim().toLocaleLowerCase("pt-BR");const items=guides.filter(g=>(activeFilter==="Todos"||g.category===activeFilter)&&(`${g.title} ${g.desc} ${g.category}`).toLocaleLowerCase("pt-BR").includes(term));guideGrid.innerHTML=items.length?items.map((g,i)=>`<article class="guide-card"><div class="guide-icon">${g.icon}</div><span class="tag">${g.category.toUpperCase()}</span><h3>${g.title}</h3><p>${g.desc}</p><button class="text-btn" data-guide="${guides.indexOf(g)}">Ler guia →</button></article>`).join(""):`<p>Nenhum guia encontrado. Tente outro termo.</p>`;}
renderGuides();
search.addEventListener("input",renderGuides);
document.querySelector("#guideFilters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;activeFilter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderGuides();});
guideGrid.addEventListener("click",e=>{const b=e.target.closest("[data-guide]");if(!b)return;showModal(`<span class="tag">${guides[+b.dataset.guide].category.toUpperCase()}</span><h3>${guides[+b.dataset.guide].title}</h3><p>${guides[+b.dataset.guide].body}</p><p><small>Conteúdo introdutório comunitário. Confirme informações que possam mudar após atualizações do jogo.</small></p>`);});
document.querySelector("#teamGrid").innerHTML=teams.map(t=>`<article class="team-card"><div class="team-emblem">${t.symbol}</div><span class="tag">PORTAL DE EQUIPES</span><h3>${t.name}</h3><p>${t.desc}</p><div class="team-meta">${t.meta}</div></article>`).join("");
const chat=document.querySelector("#chatOverlay"), chatMessages=document.querySelector("#chatMessages"), chatInput=document.querySelector("#chatInput");
function openChat(){chat.classList.add("open");chat.setAttribute("aria-hidden","false");setTimeout(()=>chatInput.focus(),80);}
function closeChat(){chat.classList.remove("open");chat.setAttribute("aria-hidden","true");}
document.querySelectorAll("[data-open-chat]").forEach(b=>b.addEventListener("click",openChat));
document.querySelector("#closeChat").addEventListener("click",closeChat);
chat.addEventListener("click",e=>{if(e.target===chat)closeChat();});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeChat();document.querySelector("#infoModal").classList.remove("open");}});
function addMessage(text,who){const d=document.createElement("div");d.className=`message ${who==="user"?"user-message":"pandalf-message"}`;d.textContent=text;chatMessages.appendChild(d);chatMessages.scrollTop=chatMessages.scrollHeight;}
async function sendMessage(){const text=chatInput.value.trim();if(!text)return;addMessage(text,"user");chatInput.value="";const btn=document.querySelector("#sendChat");btn.disabled=true;addMessage("Estou consultando meus conhecimentos…","pandalf");const pending=chatMessages.lastElementChild;
try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text})});if(!r.ok)throw new Error("AI_NOT_CONFIGURED");const data=await r.json();pending.textContent=data.reply||"Não consegui formular uma resposta agora.";}
catch{pending.textContent="Minha sabedoria ainda está sendo conectada. O portal já está preparado para receber a IA, mas o serviço de inteligência precisa ser configurado pelo administrador. Enquanto isso, consulte a Biblioteca Lendária. Não vou inventar uma resposta sobre o jogo.";}
finally{btn.disabled=false;chatInput.focus();}}
document.querySelector("#sendChat").addEventListener("click",sendMessage);
chatInput.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage();}});
const toolPanel=document.querySelector("#toolPanel");
const toolTemplates={
 race:`<h3>Simulador de corrida</h3><div class="tool-fields"><label>Pontos desejados<input id="racePoints" type="number" min="0" value="5000"></label><label>Pontos por tarefa<input id="taskPoints" type="number" min="1" value="100"></label><button class="primary-btn" id="calcRace">Calcular</button></div><div class="tool-result" id="toolResult">Informe os valores para estimar a quantidade de tarefas.</div>`,
 runes:`<h3>Planejador de runas</h3><div class="tool-fields"><label>Função do monstro<select id="runeRole"><option value="Dano">Atacante</option><option value="Tanque">Tanque</option><option value="Suporte">Suporte</option><option value="Controle">Controle</option></select></label><button class="primary-btn" id="calcRunes">Sugerir combinação</button></div><div class="tool-result" id="toolResult">Escolha uma função.</div>`,
 cave:`<h3>Simulador de gasto na Caverna</h3><div class="tool-fields"><label>Gemas disponíveis<input id="gems" type="number" min="0" value="100"></label><label>Custo por tentativa<input id="gemCost" type="number" min="1" value="5"></label><button class="primary-btn" id="calcCave">Simular</button></div><div class="tool-result" id="toolResult">A simulação não prevê resultados nem garante recompensas.</div>`
};
document.querySelectorAll("[data-tool]").forEach(b=>b.addEventListener("click",()=>{toolPanel.hidden=false;toolPanel.innerHTML=toolTemplates[b.dataset.tool];toolPanel.scrollIntoView({behavior:"smooth",block:"center"});}));
toolPanel.addEventListener("click",e=>{if(e.target.id==="calcRace"){const p=Math.max(0,Number(document.querySelector("#racePoints").value)||0),v=Math.max(1,Number(document.querySelector("#taskPoints").value)||1);document.querySelector("#toolResult").textContent=`Estimativa: ${Math.ceil(p/v)} tarefas de ${v} pontos. O valor real depende das tarefas disponíveis.`;}
if(e.target.id==="calcRunes"){const role=document.querySelector("#runeRole").value;const map={Dano:"Priorize Força; avalie Velocidade conforme a estratégia.",Tanque:"Priorize Vida e resistência; ajuste Velocidade conforme a equipe.",Suporte:"Considere Velocidade para agir no momento certo e Vida para sobreviver.",Controle:"Considere Velocidade para aplicar efeitos antes dos adversários."};document.querySelector("#toolResult").textContent=map[role];}
if(e.target.id==="calcCave"){const g=Math.max(0,Number(document.querySelector("#gems").value)||0),c=Math.max(1,Number(document.querySelector("#gemCost").value)||1);document.querySelector("#toolResult").textContent=`Com ${g} gemas e custo hipotético de ${c} por tentativa, você pode simular até ${Math.floor(g/c)} tentativas, sobrando ${g%c} gemas. Isso não prevê recompensas.`;}});
function showModal(html){document.querySelector("#modalContent").innerHTML=html;document.querySelector("#infoModal").classList.add("open");}
function closeModal(){document.querySelector("#infoModal").classList.remove("open");}
document.querySelector("#closeModal").addEventListener("click",closeModal);
document.querySelector("#infoModal").addEventListener("click",e=>{if(e.target.id==="infoModal")closeModal();});
document.querySelector("[data-team-info]").addEventListener("click",()=>showModal(`<h3>Cadastro de equipes</h3><p>O portal está preparado para receber páginas de equipes, mas o cadastro seguro de líderes, login e edição de perfis depende da próxima etapa: configurar banco de dados e autenticação.</p><p>Os líderes poderão administrar somente a própria equipe, após validação de permissões.</p>`));
document.querySelector("#menuToggle").addEventListener("click",()=>{const nav=document.querySelector("#mainNav"),open=nav.classList.toggle("open");document.querySelector("#menuToggle").setAttribute("aria-expanded",String(open));});
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>{document.querySelector("#mainNav").classList.remove("open");document.querySelector("#menuToggle").setAttribute("aria-expanded","false");}));
document.querySelector("#year").textContent=new Date().getFullYear();
